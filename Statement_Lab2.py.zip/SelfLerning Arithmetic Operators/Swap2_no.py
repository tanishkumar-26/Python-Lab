a = int(input())
b = int(input())
a, b = b, a
print(a, b)