a = int(input())
b = int(input())
print("Sum:", a+b)