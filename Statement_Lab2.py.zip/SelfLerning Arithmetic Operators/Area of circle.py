r = float(input())
print(3.14*r*r)