p = float(input())
r = float(input())
t = float(input())
si = (p*r*t)/100
print(si)