a = int(input("A: "))
b = int(input("B: "))
if a > b:
    print("A is largest")
else:
    print("B is largest")