num = int(input())
if num % 5 == 0 and num % 11 == 0:
    print("Divisible")
else:
    print("Not Divisible")