age = int(input("Age: "))
if age >= 18:
    print("Eligible")
else:
    print("Not Eligible")