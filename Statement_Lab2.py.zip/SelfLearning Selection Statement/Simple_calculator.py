a = int(input())
b = int(input())
op = input("Operator (+,-,*,/): ")

if op == "+":
    print(a+b)
elif op == "-":
    print(a-b)
elif op == "*":
    print(a*b)
elif op == "/":
    print(a/b)