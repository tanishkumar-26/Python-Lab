a = int(input())
b = int(input())
c = int(input())
if a > b and a > c:
    print("A largest")
elif b > c:
    print("B largest")
else:
    print("C largest")