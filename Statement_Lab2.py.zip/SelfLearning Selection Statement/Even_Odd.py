num = int(input("Enter number: "))
if num % 2 == 0:
    print("Even")
else:
    print("Odd")