# Salary Calculation

basic_salary = 25000

# HRA = 20% of basic
hra = basic_salary * 20 / 100

bonus = 5000

# Total salary
total_salary = basic_salary + hra + bonus

print("HRA =", hra)
print("Total Monthly Salary =", total_salary)