# Classroom Student Distribution

total_students = 125
students_per_class = 30

# Full classes
full_classes = total_students // students_per_class

# Remaining students
remaining_students = total_students % students_per_class

print("Full Classes =", full_classes)
print("Remaining Students =", remaining_students)